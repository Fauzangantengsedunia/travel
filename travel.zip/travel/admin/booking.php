<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Booking</title>
    <link rel="stylesheet" href="booking.css?v=<?php echo time(); ?>">
</head>
<body>
    <table border="1" class="table" id="user">
        <a href="../index.html"><button>log out</button></a>
        <a href="index.php"><button>Table admin</button></a>
        <a href="lihat_pembayaran.php"><button>lihat pembayaran</button></a>
        <a href="lihat_pembayaran.php"><button>Kembali</button></a>
        <tr>
            <th>no</th>
            <th>username</th>
            <th>where_to</th>
            <th>how_many</th>
            <th>arrivals</th>
            <th>leaving</th>
        </tr>
        
        <?php
        // Menggunakan koneksi mysqli atau PDO yang benar
        include('koneksi.php');

        // Select data dari tabel user
        $query_mysql = mysqli_query($mysqli, "SELECT akun.username, booking.where_to, booking.how_many, booking.arrivals, booking.leaving FROM akun JOIN booking ON akun.id_user = booking.id_user") or die(mysqli_error($mysqli));

        // Variabel nomor dimulai dari 1    
        $nomor = 1;

        // Loop untuk menampilkan data dalam tabel
        while ($data = mysqli_fetch_array($query_mysql)) {
            ?>
            <tr>
                <td><?php echo $nomor++; ?></td>
                <td><?php echo $data['username']; ?></td>
                <td><?php echo $data['where_to']; ?></td>
                <td><?php echo $data['how_many']; ?></td>
                <td><?php echo $data['arrivals']; ?></td>
                <td><?php echo $data['leaving']; ?></td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>
