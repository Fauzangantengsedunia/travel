<?php
include 'koneksi.php';
$id_user = $_GET['id_user'];

// Delete related rows from the booking table first
$deleteBooking = mysqli_query($mysqli, "DELETE FROM booking WHERE id_user = '$id_user'") or die(mysqli_error($mysqli));

// Then delete the user from the akun table
$hapus = mysqli_query($mysqli, "DELETE FROM akun WHERE id_user = '$id_user'") or die(mysqli_error($mysqli));

if ($hapus) {
    header("location: index.php");
    exit();
} else {
    echo "Gagal menghapus user";
}
?>
