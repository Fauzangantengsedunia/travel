<?php

include("koneksi.php");

if(isset($_POST['simpan'])){
    $id_user = $_POST['id_user'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $level = $_POST['level'];

    $result = mysqli_query($mysqli, "UPDATE akun SET username='$username', password='$password', level='$level' WHERE id_user=$id_user");
    header('Location: index.php');
} else {
    die("Akses Dilarang..");
}
?>
