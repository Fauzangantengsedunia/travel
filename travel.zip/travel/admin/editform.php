<?php
include("koneksi.php");

if (!isset($_GET['id_user'])) {
    header('location: index.php');
    exit();
}

$id_user = $_GET['id_user'];

$result = mysqli_query($mysqli, "SELECT * FROM akun WHERE id_user=$id_user");

if ($result) {
    $user_data = mysqli_fetch_assoc($result);
    if ($user_data) {
        $username = $user_data['username'];
        $password = $user_data['password'];
        $level = $user_data['level'];
    } 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://unpkg.com/feather-icons"></script>
    <link rel="stylesheet" href="../halamanlogin.css" />
    <title>Edit</title>
</head>
<body>
    <div class="container">
        <div class="box from-box">
            <header>Edit</header>
            <form action="edit.php" method="post">
                <div class="field-input">
                    <i data-feather="user"></i>
                    <input type="text" name="username" placeholder="Username" value="<?php echo htmlspecialchars($username); ?>" required />
                </div>
                <div class="field-input">
                    <i data-feather="lock"></i>
                    <input type="text" name="password" placeholder="Password" value="<?php echo htmlspecialchars($password); ?>" required />
                </div>
                <div class="field-input">
                    <label for="level">Level</label>
                    <select name="level" id="level">
                        <option value="user" <?php if($level == 'user') echo 'selected'; ?>>User</option>
                        <option value="admin" <?php if($level == 'admin') echo 'selected'; ?>>Admin</option>
                    </select>
                </div>
                <input type="hidden" name="id_user" value="<?php echo htmlspecialchars($id_user); ?>">
                <div class="field">
                    <input type="submit" name="simpan" value="Simpan">
                </div>
            </form>
        </div>
    </div>
    <script>
        feather.replace();
    </script>
</body>
</html>
