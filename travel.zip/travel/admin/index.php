<head>
    <title>Admin</title>
    <link rel="stylesheet" href="index.css?v=<?php echo time(); ?>">
</head>
<table border="1" class="table" id="user">
    <a href="../index.html"><button>log out</button></a>
    <a href="booking.php"><button>Table booking</button></a>
    <a href="lihat_pembayaran.php"><button>lihat pembayaran</button></a>
    <a href="../index.html"><button>Kembali</button></a>
    <tr>
        <th>No</th>
        <th>Username</th>
        <th>Password</th>
        <th>Level</th>
        <th>Tools</th>
    </tr>
    <?php
    // Menggunakan koneksi mysqli atau PDO yang benar
    include ('koneksi.php');

    // Select data dari tabel user
    $query_mysql = mysqli_query($mysqli, "SELECT * FROM akun ") or die(mysqli_error($mysqli));

    // Variabel nomor dimulai dari
    $nomor = 1;

    // Loop untuk menampilkan data dalam tabel
    while ($data = mysqli_fetch_array($query_mysql)) {
        ?>
        <tr>
            <td><?php echo $nomor++; ?></td>
            <td><?php echo $data['username']; ?></td>
            <td><?php echo $data['password']; ?></td>
            <td><?php echo $data['level']; ?></td>
            <td>
                <!-- Isi kolom aksi sesuai dengan kebutuhan -->
                <a href="delete.php?id_user=<?php echo $data['id_user'];?>">Delete</a>
                <a href="editform.php?id_user=<?php echo $data['id_user'];?>">Edit</a>
            </td>
        </tr>
    <?php } ?>
</table>