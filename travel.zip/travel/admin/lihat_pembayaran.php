<?php
include('koneksi.php');
?>
<head>
    <title>lihat pembayaran</title>
    <link rel="stylesheet" href="lihat_pembayaran.css?v=<?php echo time(); ?>">
</head>
<!DOCTYPE html>
<html>
<head>
    <title>Daftar Pembayaran</title>
</head>
<body>
    <h2>Daftar Pembayaran</h2>
    <a href="../index.php"><button>log out</button></a>
        <a href="booking.php"><button>Table booking</button></a>
        <a href="lihat_pembayaran.php"><button>lihat pembayaran</button></a>
        <a href="index.php"><button>Kembali</button></a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Jumlah</th>
            <th>Tanggal</th>
        </tr>
        <?php
        $query = "SELECT id_pembayaran, nama, jumlah, tanggal FROM pembayaran";
        $result = $mysqli->query($query);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id_pembayaran']) . "</td>";
                echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
                echo "<td>" . htmlspecialchars($row['jumlah']) . "</td>";
                echo "<td>" . htmlspecialchars($row['tanggal']) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No records found</td></tr>";
        }

        $mysqli->close();
        ?>
    </table>
</body>
</html>
