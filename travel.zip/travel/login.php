<?php
session_start();
include 'koneksi.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['Username']; 
    $password = $_POST['Password'];

    $login = mysqli_query($mysqli,"SELECT * FROM akun WHERE username='$username' AND password='$password'");
    $cek = mysqli_num_rows($login);

    if($cek > 0){
        $data = mysqli_fetch_assoc($login);
        $_SESSION['username'] = $username;
        
        if($data['level'] == "admin"){
            $_SESSION['level'] = "admin";
            header("Location: admin/index.php");
        } else if($data['level'] == "user"){
            $_SESSION['level'] = "user";
            header("Location: user/index.html");
        } else {
            header("Location: login/login.html");
        }
    } else {
        header("Location: index.html?pesan=gagal");
    }
}
?>
