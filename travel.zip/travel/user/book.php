<head>
<link rel="stylesheet" href="book.css?v=<?php echo time(); ?>">
</head>

<?php
session_start();
include('../koneksi.php');

// Enable error reporting for debugging purposes
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    die("Anda harus login untuk mengakses halaman ini!");
}

$username = $_SESSION['username']; // Ambil username dari sesi

// Dapatkan id_user berdasarkan username
$query = mysqli_query($mysqli, "SELECT id_user FROM akun WHERE username='$username'");

// Cek apakah query berhasil dijalankan
if ($query) {
    $user_data = mysqli_fetch_assoc($query);
    $id_user = $user_data['id_user'];
} else {
    die("Error: " . mysqli_error($mysqli));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $where_to = $_POST['where_to'];
    $how_many = $_POST['how_many'];
    $arrivals = $_POST['arrivals'];
    $leaving = $_POST['leaving'];
    $name = $_POST['name'];
    
    // Debug: Check if name is correctly captured
    echo "$name<br>";
    
    // Check connection
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }
    
    // Prepare and bind
    $stmt = $mysqli->prepare("INSERT INTO booking (id_user, where_to, how_many, arrivals, leaving, name) VALUES (?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare statement failed: " . $mysqli->error);
    }
    
    $stmt->bind_param("isssss", $id_user, $where_to, $how_many, $arrivals, $leaving, $name);
    
    // Execute the statement
    if (!$stmt->execute()) {
        die("Execute statement failed: " . $stmt->error);
    }
    
    // Close statement and connection
    $stmt->close();
    $mysqli->close();
    
    // Redirect or display success message
    header("Location: index.html");
        exit();
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Booking Form</title>
    </head>
    <body>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <h2>Booking Form</h2>
        <p>Nama: <span><?php echo htmlspecialchars($username); ?></span></p>
        <input type="hidden" name="name" value="<?php echo htmlspecialchars($username); ?>">
        Where To: <input type="text" name="where_to" required><br>
        How Many: <input type="number" name="how_many" required><br>
        Arrivals: <input type="date" name="arrivals" required><br>
        Leaving: <input type="date" name="leaving" required><br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
