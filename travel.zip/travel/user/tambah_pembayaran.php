<head>
<link rel="stylesheet" href="tambah_pembayaran.css?v=<?php echo time(); ?>">
</head>

<?php
session_start();
include ('../koneksi.php');

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['username'])) {
    die("Anda harus login untuk mengakses halaman ini!");
}

$username = $_SESSION['username']; // Ambil username dari sesi

// Dapatkan id_user berdasarkan username
$query = mysqli_query($mysqli, "SELECT id_user FROM akun WHERE username='$username'");

// Cek apakah query berhasil dijalankan
if ($query) {
    $user_data = mysqli_fetch_assoc($query);
    $id_user = $user_data['id_user'];
} else {
    die("Error: " . mysqli_error($mysqli));
}

// Menangani form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $jumlah = $_POST['jumlah'];
    $tanggal = $_POST['tanggal'];

    // Prepare and bind
    $stmt = $mysqli->prepare("INSERT INTO pembayaran (id_user, nama, jumlah, tanggal) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare statement failed: " . $mysqli->error);
    }
    
    $stmt->bind_param("isss", $id_user, $nama, $jumlah, $tanggal);
    
    // Execute the statement
    if (!$stmt->execute()) {
        die("Execute statement failed: " . $stmt->error);
    }

    // Close statement and connection
    $stmt->close();
    $mysqli->close();

    // Redirect or display success message
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pembayaran</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <h2>Form Pembayaran</h2>
        <p>Nama: <span><?php echo htmlspecialchars($username); ?></span></p>
        <input type="hidden" name="nama" value="<?php echo htmlspecialchars($username); ?>">
        Jumlah: <input type="number" step="1" name="jumlah" required><br>
        Tanggal: <input type="date" name="tanggal" required><br>
        <input type="submit"  value="Submit">
    </form>
</body>
</html>
